# Injectomat Agilia -> ESP32-S3 : decoder + JSON uploader + WiFi / LAN + OTA by device model / serial

Open this folder (the one containing `platformio.ini`) in VS Code / PlatformIO. Build, upload by cable once.
After that: `http://mydevice.local` (login in `config.h`) -> Dashboard / Settings / Firmware update.

## New in 1.2.4: made for your exact UART line (module pads 36 / 37)
From the ESP32-S3-WROOM-1 pin table you gave:

| Module pad | Name | Functions | GPIO | In this firmware |
|---|---|---|---|---|
| 36 | RXD0 | I/O/T, U0RXD, CLK_OUT2 | **GPIO44** | **the pump's TX goes here**: default pump RX pin (`PUMP_RX_PIN 44`) |
| 37 | TXD0 | I/O/T, U0TXD, CLK_OUT1 | GPIO43 | not used (`PUMP_TX_PIN -1`): left high-impedance, so it can never fight the pump's output |

Factory settings now: pump on **RXD0 / GPIO44**, 115200 baud 8N1 (UART1 is routed to that pin). UART0 is also the debug console, so by default the console is **switched off** while the pump uses it
(nothing is ever transmitted towards the pump; read the log on the Dashboard page, LAN and test results are on the Settings page).

**Wiring cases**
1. **Normal use:** pump TX -> RXD0, pump GND -> gateway GND. **Pump RX wire unconnected**, TXD0 unused. Nothing else on the line.
2. **Debugging with serial logs while the pump streams:** Settings -> Pump serial input -> tick **"keep the serial console on TXD0"**, Save & reboot. Then connect your USB-UART adapter's **RX** to TXD0 and its GND;
   leave the adapter's TX unconnected (RXD0 belongs to the pump). The pump's RX wire must stay disconnected, otherwise debug text enters the pump.
3. **Flashing:** adapter TX -> RXD0, adapter RX -> TXD0, BOOT + RESET. Disconnect the pump first (it uses the same pins).

If you saved pump settings with v1.2.3 (for example GPIO17), that saved value stays: set RX pin to **44** on the page, or press **Find the pump line now** (it also runs once by itself 30 s after start-up when no pump data has arrived).
Pins other than 43/44 for the pump (for example GPIO17) remain possible on the same page.

## New in 1.2.3: the pump serial line on the Minew gateway (UART pins)
**Status of the LAN:** working (W5500 found, DHCP address, TCP and test message reach the server).
**What was wrong with the pump data:** the firmware listened on **UART1, GPIO17, RX only, no TX, 115200 8N1** (the pins used before). The TTL header of the Minew gateway is not wired to
GPIO17: it is the console / programming UART, **UART0 = GPIO44 (ESP32 RX) and GPIO43 (ESP32 TX)**. Flashing with the adapter's TX on the header pin labelled "TX" works,
so the header's "TX" pin reaches the ESP32 **RX** (GPIO44). The pump's TX wire on that pin therefore arrives on GPIO44, where the old firmware was not listening.

| | Before | Now |
|---|---|---|
| Pump line | fixed: UART1 on GPIO17 (RX), no TX, 115200 | **saved setting** (Settings -> Pump serial input): RX pin, TX pin (none), baud |
| Console / flashing | UART0 GPIO43/44, always on | UART0 GPIO43/44; **switched off** when the pump line is on those pins |
| Finding the pin | by hand, in config.h | **"Find the pump line"** button, and once automatically after start-up when no pump data arrives |

**Wire it like this:** pump **TX -> the header pin labelled TX** (the one that reaches GPIO44), pump **GND -> gateway GND**, and leave the **pump RX line unconnected**.
The firmware only listens; with the pump RX connected to the header's RX pin the gateway's boot text (ROM bootloader, debug lines) would be sent into the pump.
Do not connect the USB-UART adapter at the same time as the pump (same two pins).

**One-time check (nothing to configure):** power the pump on and connect the wires. With the factory setting "find the pump line automatically", the gateway waits 30 s after start-up;
if no valid pump frame has arrived it listens once on GPIO44, 43, 17 and 18 (3.5 s each, CRC-checked Agilia frames, so noise cannot fool it). If the pump is found on another pin, the pin is saved and
the gateway restarts by itself. You can also press **Settings -> Pump serial input -> Find the pump line now** at any time; the results show bytes and valid frames per pin and "Use GPIOxx".
What to read: `RECEIVING: 8 valid frames ...` = working; `NO BYTES received` = wiring (TX wire, GND, pump powered on); `bytes arrive but no valid frame` = wrong baud rate, noise, or RS-232 voltage levels
(a true RS-232 pump output must go through a level shifter such as a MAX3232: never connect +-12 V directly to the ESP32).
When the pump line is on GPIO43/44 the serial monitor is silent by design: read the log on the Dashboard page.

## New in 1.2.2: verified against the working reference firmware (Minew gateway)
The reference project `esp32s3_ble_gateway_standalone` already pushes data over this gateway's LAN. Reading its source showed why this firmware's LAN could not work:

| | Reference firmware (works) | This firmware before 1.2.2 | Now |
|---|---|---|---|
| W5500 pins | SCK 41, MISO 40, MOSI 39, CS 42, RST 37 | generic 12, 13, 11, 10, 5 | **same as the reference** |
| W5500 INT pin | none (the Arduino Ethernet library polls the chip) | **required** by the ESP-IDF driver (it refuses to start without one, and only reads packets when INT fires) | INT optional: without INT a small task wakes the driver every 4 ms |
| MAC address | fixed `DE:AD:BE:EF:FE:ED` | derived from the chip | selectable: automatic or fixed (reference MAC offered) |
| Reset timing | RST low 100 ms, then 500 ms wait | 10 ms / 60 ms | 100 ms / 300 ms |
| SPI clock | 14 MHz (library default) | 20 MHz | 14 MHz |
| Network stack | WIZnet hardware TCP/IP (`Ethernet.h`) | lwIP over the ESP-IDF W5500 driver | unchanged (the web page, OTA, mDNS and uploads need lwIP) |

So even with the right pins the old build would have seen the cable (link up) but never received a packet (no DHCP answer, no ping, nothing) because the INT wire does not exist on this board.
**Module:** the reference's Ethernet build targets the ESP32-S3-WROOM-1 **N8R2** (8 MB flash, 2 MB quad PSRAM): use the PlatformIO environment `wroom1u_8mb`. PSRAM is not used by this firmware.
Other things seen in the reference: it tries Ethernet first and falls back to WiFi (here: network mode "LAN first, WiFi backup"), and its fixed MAC is the same in every unit (fine for one gateway, a problem for several on one network).

**Serial lines to expect on the Minew gateway:**
```
LAN: W5500 answered (chip version 0x04): the SPI wiring and pins are correct
LAN: MAC address DE:AD:BE:EF:FE:ED (fixed)        or  (automatic)
LAN: INT pin not used -> the W5500 is polled every 4 ms (no INT wire needed)
LAN: W5500 on SPI @14 MHz (SCLK=41 MISO=40 MOSI=39 CS=42 INT=-1 RST=37), address mode: DHCP
LAN: cable connected (link up)
LAN: IP 172.16.x.y mask ... gateway ...
```
**If DHCP gets no answer:** some office networks only allow known devices (MAC filtering). Settings -> Network interface -> LAN MAC address -> **Fixed**, press "Use the reference firmware's MAC", Save.
Use this on ONE gateway per network only.

## New in 1.2.1: office LAN, finding out why it does not work
- **Connection test** (Settings page, new card). Runs on the gateway and says in plain words where the way to your computer breaks:
  no IP address / wrong network / firewall (no answer) / port closed (refused) / server error. Optionally sends one test message.
- **LAN chip check at start-up.** The firmware reads the W5500 version register (a W5500 always answers `0x04`) before starting the driver, and prints it:
  `LAN: W5500 answered (chip version 0x04) ...` or `LAN: NO ANSWER (read 0xFF ...)`. The same text is on the Settings page. **Find the LAN chip** tries the known pin sets.
- **Bug fixed: host names in LAN-only mode.** DNS lookups (a server given as a NAME, like `nexus.api.lifesigns.us`) failed when the WiFi stack was never started. IP addresses were not affected.
- **DHCP wait is now a setting** (default 30 s, was a fixed 15 s). On an office network the switch may need 30 s to open the port; with a too short wait the gateway
  fell back to the static `192.168.50.2`, which does not exist on the office network. For an office LAN use **DHCP** only.
- **Readable errors**: serial `POST failed, code=-1 (could not connect: refused, or no answer ...) -> http://172.16.22.201:8080/api/pump via ethernet 172.16.22.50`
  and the same words on the Dashboard.

## Setup: gateway on the OFFICE LAN, laptop on the office Wi-Fi
**The one thing that decides everything:** the gateway (wired) and the laptop (Wi-Fi) must be able to reach each other. Many offices put wired and Wi-Fi on
different networks and block traffic between them. The Connection test tells you.

1. **Laptop.** `ipconfig` -> IPv4 of the **Wi-Fi** adapter (for example `172.16.22.201`, mask `255.255.254.0`). Administrator Command Prompt, once:
   `netsh advfirewall firewall add rule name="Agilia test server" dir=in action=allow protocol=TCP localport=8080 profile=any`
   (`profile=any` matters: Wi-Fi networks are usually "Public" and Public blocks inbound traffic.) Then `python server.py` and leave it running.
2. **Gateway: Settings -> Network interface.** Use: **LAN cable only** (or LAN first, WiFi backup). LAN address: **DHCP**. Leave the static fields.
   LAN chip pins: preset **Minew standalone gateway** (default). Save & reboot (15-30 s).
3. **Find the gateway's address.** Serial monitor: `LAN: IP 172.16.x.y mask ... gateway ...`, or the DHCP list of your router/IT. Open `http://<that IP>`.
   The Settings page shows `LAN: connected, address from DHCP`. If it shows "static address (DHCP did not answer)": no DHCP reached the gateway: cable/port, or raise "Wait for DHCP".
4. **Gateway: Settings -> Server.** Protocol `http`, host = the laptop's address from step 1, port `8080`, path `/api/pump`, header fields empty. **Save.**
5. **Settings -> Connection test** (host/port empty = the Server card): tick "also send one small test message", **Run test**. Read the result:

| Result line | Meaning and what to do |
|---|---|
| `FAIL The gateway has NO IP address` + `The LAN chip did not start` | The W5500 does not answer: wrong pins for this board. Use **Find the LAN chip** (it tries the Minew pins first). |
| `FAIL ... No LAN link` | Cable, switch port, link LED. |
| `NOTE ... STATIC fallback address` | DHCP did not answer in time. Choose DHCP, raise the wait, check the port, or set a fixed LAN MAC (MAC filtering). |
| `NOTE The target ... is on ANOTHER network` | Gateway and laptop are in different networks; packets go through the router. Fine only if the office network allows wired -> Wi-Fi traffic. |
| `FAIL NO ANSWER after 6000 ms` | The laptop does not answer: Windows firewall (profile), wrong laptop IP (laptop address changes with DHCP: `ipconfig` again), or the office network blocks it. Test with the laptop on a **cable** in the same network as the gateway. |
| `FAIL REFUSED` | The laptop answered but nothing listens on that port: start `python server.py`, check port 8080. |
| `FAIL NO ROUTE` | Wrong mask or gateway address on the gateway. |
| `OK TCP connection OK` then `Server answered 200` | The data path works. The dashboard at `http://localhost:8080` should now show frames (a gateway named `mydevice` and `mydevice-test`). |
| `Server answered 404 / 401 / 500` | Wrong Path / wrong header key / server error. |

6. **Pump data.** Connect the pump; the serial monitor shows `[stats] ... posts ok=` rising, the server window `POST /api/pump 200 ...`.

## What is new in 1.2.0 (for the ESP32-S3-WROOM-1U module)
1. **LAN cable (Ethernet)** next to WiFi: WiFi only / LAN only / LAN first with WiFi backup. WiFi code is unchanged.
2. **The gateway knows what it is connected to**: syringe pump (Injectomat) or infusion pump (Volumat) are detected from
   the data; other devices (patient monitor ...) are typed in.
3. **Firmware updates chosen by device class, model or serial number**: a guarded upload, a push tool for many gateways,
   and a server-managed update.

## 1. LAN cable
**Hardware: WIZnet W5500 on SPI.** The ESP32-S3 has no built-in Ethernet MAC, so the LAN port is the W5500 chip on the SPI bus
(a W5500 wired to the module on your own board). Pins and SPI clock are saved in flash and are edited on
**Settings -> Network interface -> LAN chip pins**, so a different wiring needs no rebuild.
**The default preset is the Minew standalone gateway**, with the pins taken from the working reference firmware (see "Verified against the reference firmware"):

| W5500 signal | ESP32-S3 GPIO | Note |
|---|---|---|
| SCLK | 41 | GPIO39-42 are the S3's JTAG pins; they work as normal GPIO (no JTAG debugging) |
| MISO | 40 | |
| MOSI | 39 | |
| CS | 42 | |
| RST | 37 | only valid on modules **without octal PSRAM** (N8R2 yes, N16R8 / N8R8 no) |
| INT | **not wired** | leave the field empty: the firmware polls the chip every 4 ms |
| pump TX | **RXD0 = GPIO44** (module pad 36), default | see "New in 1.2.4" above |

Other presets (drop-down): ESP32-S3 module with INT on GPIO4 and FSPI pins 10-13, Waveshare ESP32-S3-ETH, LilyGO T-ETH-Lite-S3, or "Custom wiring".
The compile-time defaults are `ETH_BOARD` in `config.h` section 3b. Avoid GPIO 0, 3, 45, 46 (boot pins) and 19/20 (USB) on your own boards. The page refuses pins that do not exist,
are the flash (26-32), the console (43/44), repeat, or clash with the pump UART. Other Ethernet chips (DM9051, CH390, ENC28J60) would need a different driver.

**Settings page -> Network interface** (saved in flash, reboot on save):

| Mode | WiFi radio | Hotspot | Use |
|---|---|---|---|
| WiFi only | on | as before | set `NET_DEFAULT_MODE 0` to make this the default |
| LAN cable only | never started | none | **default of this build**, hospital rooms without WiFi |
| LAN first, WiFi backup | on | not while the cable works | cable normally, WiFi if unplugged |

**LAN address:** DHCP, static, or *DHCP first, static if no DHCP server answers within N s* (default; N = "Wait for DHCP", default 30 s). On an office network use plain **DHCP**.

**Direct cable to one Windows PC (no router):**
1. Windows: Settings -> Network -> Ethernet adapter -> IP: manual, `192.168.50.1`, mask `255.255.255.0`, gateway empty.
2. Gateway: LAN only, address mode "DHCP then static" (defaults 192.168.50.2 / 255.255.255.0). After the DHCP wait (30 s) it uses 192.168.50.2.
3. Open `http://192.168.50.2` (login in `config.h`). `mydevice.local` often works too, the IP always does.
4. Settings -> Server: scheme `http`, host `192.168.50.1`, port `8080`, path `/api/pump`. Start `server.py` of the test server. Allow it through the Windows firewall.

**Locked out after a wrong address? (no page opens, no WiFi, no button, no serial cable)** Four ways back, easiest first:
1. **Quick power cycles - needs nothing.** Switch the gateway's power OFF and ON **5 times in a row**, cutting the power each time within 8 seconds of switching on
   (do not wait for the LAN). The 5th power-on resets the network settings by itself and restarts: **LAN only, DHCP first, then `192.168.50.2 / 255.255.255.0`**.
   Leave the power on, set your PC to `192.168.50.1 / 255.255.255.0` and open `http://192.168.50.2`. The serial monitor (if connected) prints
   `Quick power cycle 1 of 5 ... 4 of 5` and then `*** Network settings reset to defaults ***`. WiFi list, server, device and update settings are kept.
   Settings: `NET_POWERCYCLE_COUNT` / `NET_POWERCYCLE_WINDOW_MS` in `config.h` (0 = off). A supply that browns out and restarts in a loop also counts as power cycles.
2. **Move the PC into the gateway's subnet.** If you know the saved address (for example 10.0.0.5/24): `netsh interface ip set address name="Ethernet" static 10.0.0.1 255.255.255.0`, then open `http://10.0.0.5`.
3. **BOOT button** (GPIO0, `NET_RESET_PIN`): hold 5 s while running, only if your board has a button on GPIO0.
4. **Erase the flash** (last resort, wipes ALL saved settings): `pio run -e wroom1u_4mb -t erase`, then upload again.

What a reset returns to is `NET_DEFAULT_MODE` in `config.h`. **This build ships with `1` = LAN only**, so a fresh or reset gateway never switches a radio on and there is no hotspot.
(With `0` a reset would return to WiFi and open the hotspot `Agilia-Router-Setup` after about 30 s.) The reset also restores the LAN chip pins to the `ETH_PIN_...` values in `config.h`.
A malformed address or mask is refused by the page, so only a valid-but-wrong address can lock you out.

**Serial monitor lines:** `LAN: W5500 on SPI @20 MHz (SCLK=12 MISO=13 ...)`, `LAN: W5500 started`, `LAN: cable connected`, `LAN: IP ...`.
`LAN: W5500 not found` = wrong pins, no 3.3 V on the module, a loose SPI wire (try 10 MHz) or INT not connected.
Upload code `-100` now means "no IP address on the interface in use" (WiFi or LAN). Time: NTP needs internet; on an isolated LAN `received_at` is left out of the JSON (the gateway `uptime_ms` is always there). Set `NTP_SERVER_1` to a hospital NTP server if you have one.

## ESP32-S3-WROOM-1U module on your own board (not a DevKit)
**1. Pick the PlatformIO environment that matches the module label** (VS Code: bottom bar -> environment name). Flash size must not be bigger than the chip,
otherwise the module aborts at start-up with a flash size error.

| Label on the module | Flash | Environment | OTA app slot |
|---|---|---|---|
| ESP32-S3-WROOM-1U-**N4**... | 4 MB | `wroom1u_4mb` (**default, runs on every variant**) | 1.25 MB |
| ESP32-S3-WROOM-1U-**N8**... | 8 MB | `wroom1u_8mb` | 3.2 MB |
| ESP32-S3-WROOM-1U-**N16**... | 16 MB | `wroom1u_16mb` | 6.25 MB |

`R2` = 2 MB quad PSRAM, `R8` = 8 MB **octal** PSRAM. This firmware does not use PSRAM. For the **R8** modules set `MODULE_PSRAM_OCTAL 1` in `config.h`
(GPIO35-37 belong to the PSRAM there; the Settings page then refuses them). Not sure of the variant? Build `wroom1u_4mb`; the first serial lines say
`Chip: ESP32-S3 rev .., flash 8 MB, PSRAM ..` and, if the module is bigger than the build, which environment to use. Switching environment changes the flash layout:
upload once by cable. Over-the-air updates keep the layout of that first upload, and an image built for `wroom1u_4mb` runs on every module.

**2. Programming and the Serial Monitor: UART0.** A bare module has no USB chip. Wire a 3.3 V USB-UART adapter:

| Adapter | Module |
|---|---|
| TX | RXD0 = GPIO44 |
| RX | TXD0 = GPIO43 |
| GND | GND |

Enter download mode: hold the BOOT button (GPIO0 to GND), tap RESET (EN to GND), release BOOT, then upload (`pio run -e wroom1u_4mb -t upload`).
Press RESET after the upload. An adapter with DTR/RTS and the usual two-transistor auto-reset circuit does this by itself. Monitor at 115200 baud.
If your board has a USB connector on GPIO19/20 instead, set `-DARDUINO_USB_CDC_ON_BOOT=1` in `platformio.ini` (the Settings page then reserves 19/20 instead of 43/44).

**3. Minimum circuit around the module** (see Espressif's *ESP32-S3 Hardware Design Guidelines* and the module datasheet):
3.3 V supply that can deliver at least 500 mA (WiFi bursts), 10 uF + 100 nF close to the 3V3 pin, EN with 10 k pull-up to 3V3 and 1 uF to GND plus a RESET button,
GPIO0 with a 10 k pull-up and a BOOT button to GND. Leave GPIO3, 45 and 46 unconnected or at their defaults (strapping pins). The W5500 needs its own 3.3 V (about 130 mA).

**4. Antenna.** The "U" version has **no PCB antenna**, only a u.FL connector. For WiFi fit a 2.4 GHz antenna; in LAN-only mode no antenna is needed.

**5. Usable GPIOs on the module:** 0-21 and 35-48. Not available: 22-34. Not for the LAN chip: 43/44 (the console), 17 (pump RX), 35-37 on R8 modules.
Avoid 0, 3, 45, 46 (boot) and 19/20 (USB).

**6. Network reset without a button:** the 5-quick-power-cycles method works on any board. The BOOT-button reset (hold GPIO0 for 5 s while running) needs a button on GPIO0; no button? Set `NET_RESET_PIN` in `config.h` to another pin that has one, or `-1`.

## 2. Connected device
`device_id.cpp` reads model, serial and software version from every Agilia status frame.

| Device | Class | How known |
|---|---|---|
| Injectomat Agilia | `syringe_pump` | detected |
| Volumat Agilia | `infusion_pump` | detected |
| Patient monitor, anything else | `patient_monitor` / `other` | **typed in** on Settings -> Connected device |

The gateway has **no decoder for patient monitors**: for those it can be identified and targeted for updates, but their data is not decoded.
The JSON now also carries `device.class`, `gateway.iface` and `gateway.ip`. The last detected device is remembered in flash but only counts as *live*
while frames keep arriving (`FLEET_LIVE_WINDOW_MS`, 10 min), so an update rule is never applied for a device that is no longer connected.

## 3. Firmware update by class / model / serial number
Filters use `*` (any text) and `?` (one character), upper/lower case ignored: `Volumat*`, `018090/*`, `018090/2208310?X`.

**a) Browser upload with a guard (`/ota`).** Fill in class / model / serial; the gateway compares them with the device connected right now and
refuses the file (HTTP 409) on a mismatch. Empty = update whatever is connected.

**b) Push to many gateways from the PC: `tools/ota_push.py`.**
```
python tools/ota_push.py .pio/build/wroom1u_4mb/firmware.bin --hosts 192.168.50.2 192.168.50.3 --model "Volumat*" --dry-run
python tools/ota_push.py firmware.bin --hosts-file gateways.txt --serial "018090/*" --password <WEB_PASS>
```
It reads each gateway's device, skips non-matching ones, uploads with the guard, and the gateway checks again (a device swapped a second earlier cannot get the wrong image).

**c) Server-managed update (off by default).** Firmware update page -> Server-managed update: mode Off / Check only / Check and install automatically,
update server URL (empty = the Settings server), path `/api/ota/check`, interval. The gateway asks

```
GET <server>/api/ota/check?gw=<id>&mac=..&fw=<running>&iface=..&class=..&model=..&serial=..&devver=..&manual=0&last=<last install result>
-> {"update":true,"version":"1.3.0","url":"/firmware/gateway-1.3.0.bin","sha256":"<64 hex>","size":1048576,"rule":"all Volumat","force":false}
-> {"update":false,"reason":"..."}
```
and installs only if: a device frame was seen in the last 10 min, the file size and SHA-256 match the offer, the version is newer (or `force`),
and, for automatic installs, no infusion is in progress. The first boot after an install confirms the new version; a version that did not take is not retried in a loop.
A failed install is retried at the next scheduled check. The test server implements the server side (rules in `manifest.json`, see its README).
The data server's header key is sent only if the update URL is the Settings server (never to another host).

## Where to change what
| I want to change... | File |
|---|---|
| LAN default pins, LAN defaults, NTP, reset button, update safety limits | `src/config.h` (sections 3b and 7); the pins can also be changed on the Settings page |
| WiFi list, server, network, device, update settings saved in flash | `src/settings.cpp` |
| WiFi / LAN / both, mDNS + NTP for LAN | `src/net_manager.cpp` |
| LAN driver (W5500, DHCP, static, fallback, chip check) | `src/eth_lan.cpp`; pin rules `src/eth_pins.cpp` |
| Connection test | `src/diag.cpp` |
| Pump pin finder, auto-find once, console on/off | `src/pump_scan.cpp`, `src/pump_reader.cpp`; pin rules `src/eth_pins.cpp` |
| How WiFi connects, hotspot | `src/wifi_manager.cpp` (unchanged except: no hotspot while the LAN works) |
| Device model / serial detection | `src/device_id.cpp` |
| Wildcards, version compare (PC-tested) | `src/fleet_logic.cpp` |
| Power-cycle reset counter (PC-tested) | `src/recovery_logic.cpp`, used by `src/net_manager.cpp` |
| Server-managed update | `src/fleet_ota.cpp` |
| Upload guard | `src/ota_update.cpp` |
| Decoding / JSON field names | `src/agilia.cpp` |
| Pages and API | `src/web_pages.h`, `src/web_server.cpp` |

## Data flow
```
pump TX -> UART -> pump_reader (parser + decoder) -> JSON -> http_sender -> WiFi or LAN -> your server
                                  |-> device_id (model, serial) -> upload guard, fleet_ota
                                  \-> latest JSON + log -> web_server -> browser
```

## Build in VS Code (PlatformIO)
1. Install the extension "PlatformIO IDE" and restart VS Code. Open the folder that DIRECTLY contains `platformio.ini`.
2. Choose the environment (see the module section above). Build with the check mark in the bottom bar, upload with the arrow.
   Terminal: `pio run -e wroom1u_4mb`, `pio run -e wroom1u_4mb -t upload`, `pio device monitor`.
3. The firmware file is `.pio/build/<environment>/firmware.bin`. PlatformIO checks it against the OTA slot size of that environment and fails the build if it does not fit
   (this version adds the LAN driver and update client; on `wroom1u_4mb` the limit is 1,310,720 bytes - if it does not fit, use an 8 MB / 16 MB module with the bigger environment).

## Tests (on a PC, not part of the firmware)
```
cd tools
g++ -std=c++11 -Wall -Wextra -I../src fleet_test.cpp ../src/fleet_logic.cpp -o fleet_test && ./fleet_test     # wildcards, versions, URL, JSON
g++ -std=c++11 -Wall -Wextra -I../src native_test.cpp ../src/agilia.cpp -o native_test && python3 make_test_frames.py | ./native_test
g++ -std=c++11 -Wall -Wextra -I../src pins_test.cpp ../src/eth_pins.cpp -o pins_test && ./pins_test            # LAN pin rules
g++ -std=c++11 -Wall -Wextra -I../src recovery_test.cpp ../src/recovery_logic.cpp -o recovery_test && ./recovery_test   # power-cycle reset counter
python3 test_ota_push.py                                                                                        # push tool vs fake gateways
```
The firmware sources were also compile-checked against the Arduino-ESP32 2.0.17 headers and the Xtensa ESP32-S3 toolchain, in 6 configurations
(default W5500 preset, console on native USB, octal PSRAM module, LAN off, the other two board presets, custom pins, no network, LAN-only default). **They have not been run on hardware.**

## Known limits
- LAN driver and update client are untested on real hardware. First test: cable, LAN only, direct to the PC, read the serial monitor.
- Firmware images are not signed. The SHA-256 comes from the same server as the file: it detects corruption, not a malicious server. For real hospital use put the update server on HTTPS and plan signed images (Secure Boot).
- Unchanged from 1.1.x: `config.h` holds WiFi passwords and the web login (`admin` / `admin123`, change it), and HTTPS does not verify the server certificate (`HTTPS_ROOT_CA nullptr`).
