#include "wifi_manager.h"
#include "config.h"
#include "settings.h"
#include "utils.h"
#include "net_manager.h"
#include "eth_lan.h"
#include <WiFi.h>
#include <WiFiMulti.h>
#include <ESPmDNS.h>
#include <time.h>

static WiFiMulti        wifiMulti;
static volatile bool    apOn = false;
static volatile uint32_t scanStartMs = 0;     // web page scan in progress (to not collide with wifiMulti)
static int              knownNetworks = 0;

bool wifiIsConnected() { return WiFi.status() == WL_CONNECTED; }
bool wifiApActive()    { return apOn; }

// ---------------------------------------------------------------- known networks
static int addKnownNetworks() {
  int n = 0;
  const int saved = settingsWifiCount();
  for (int i = 0; i < saved; i++) {
    SavedWifi w;
    if (settingsWifiGet(i, w) && w.ssid.length()) {
      wifiMulti.addAP(w.ssid.c_str(), w.pass.length() ? w.pass.c_str() : nullptr);
      n++;
    }
  }
#if USE_DEFAULT_WIFI
  for (const auto& d : DEFAULT_WIFI_LIST) {
    bool overridden = false;                              // same SSID saved on the web page wins
    for (int i = 0; i < saved; i++) {
      SavedWifi w;
      if (settingsWifiGet(i, w) && w.ssid == d.ssid) overridden = true;
    }
    if (!overridden) { wifiMulti.addAP(d.ssid, d.pass); n++; }
  }
#endif
  return n;
}

// ---------------------------------------------------------------- setup hotspot
static void startAp() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(AP_SSID, AP_PASS);
  apOn = true;
  Serial.printf("WiFi: no network joined -> setup hotspot \"%s\" ON, open http://%s\n",
                AP_SSID, WiFi.softAPIP().toString().c_str());
}

static void stopAp() {
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  apOn = false;
  Serial.println("WiFi: connected -> setup hotspot OFF");
}

// ---------------------------------------------------------------- task
static void wifiTask(void*) {
  bool mdnsOn = false, ntpOn = false, first = true;
  const bool ownServices = (netMode() == NET_WIFI);     // in LAN modes net_manager does NTP + mDNS for both interfaces
  uint32_t downSince = millis(), lastTry = 0;

  for (;;) {
    const bool scanBusy = scanStartMs && (millis() - scanStartMs < 15000);

    if (WiFi.status() != WL_CONNECTED) {
      if (mdnsOn) { MDNS.end(); mdnsOn = false; }
      ntpOn = false;

      const uint32_t interval = apOn ? 60000 : 5000;      // retry gently while hotspot is on
      if (knownNetworks > 0 && !scanBusy && (first || millis() - lastTry >= interval)) {
        first = false;
        lastTry = millis();
        Serial.println("WiFi: connecting to a known network ...");
        if (wifiMulti.run(10000) == WL_CONNECTED) {
          Serial.printf("WiFi connected: %s  IP: %s\n", WiFi.SSID().c_str(), WiFi.localIP().toString().c_str());
        }
      }
#if AP_FALLBACK_ENABLE
      // (LAN first mode: no setup hotspot while the cable works)
      if (!apOn && WiFi.status() != WL_CONNECTED && !ethHasIp() && millis() - downSince >= AP_START_DELAY_MS) startAp();
#endif
    } else {
      downSince = millis();
      if (apOn) {
        stopAp();
        if (mdnsOn) { MDNS.end(); mdnsOn = false; }
      }
      if (ownServices && !ntpOn) { configTime(0, 0, NTP_SERVER_1, NTP_SERVER_2); ntpOn = true; }
      if (ownServices && !mdnsOn && MDNS.begin(HOSTNAME)) {
        MDNS.addService("http", "tcp", 80);
        mdnsOn = true;
        Serial.printf("Web page: http://%s.local  (or http://%s)\n", HOSTNAME, WiFi.localIP().toString().c_str());
      }
    }
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

void wifiManagerBegin() {
  WiFi.mode(WIFI_STA);
  WiFi.setHostname(HOSTNAME);
  WiFi.setSleep(false);
  knownNetworks = addKnownNetworks();
  Serial.printf("WiFi: %d known network(s)\n", knownNetworks);
  xTaskCreatePinnedToCore(wifiTask, "wifiTask", 6144, nullptr, 1, nullptr, 0);
}

// ---------------------------------------------------------------- scan for the web page
// 1st call starts a scan -> {"status":"scanning"}; later calls return the list when it is done.
String wifiScanJson() {
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) return "{\"status\":\"scanning\"}";
  if (n < 0) {                                            // no scan yet -> start one (async)
    scanStartMs = millis();
    WiFi.scanNetworks(true, false);
    return "{\"status\":\"scanning\"}";
  }

  String out = "{\"status\":\"done\",\"networks\":[";
  bool firstItem = true;
  for (int i = 0; i < n && i < 30; i++) {
    String ssid = WiFi.SSID(i);
    if (ssid.length() == 0) continue;
    bool dup = false;                                     // keep the first (strongest) entry per SSID
    for (int k = 0; k < i; k++) if (WiFi.SSID(k) == ssid) { dup = true; break; }
    if (dup) continue;
    if (!firstItem) out += ",";
    firstItem = false;
    out += "{\"ssid\":\"" + jsonEscape(ssid) + "\",\"rssi\":" + String(WiFi.RSSI(i)) +
           ",\"secure\":" + (WiFi.encryptionType(i) != WIFI_AUTH_OPEN ? "true" : "false") + "}";
  }
  out += "]}";
  WiFi.scanDelete();
  scanStartMs = 0;
  return out;
}
