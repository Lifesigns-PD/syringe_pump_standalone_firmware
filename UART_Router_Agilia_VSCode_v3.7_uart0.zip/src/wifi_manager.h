/*
 * wifi_manager.h / wifi_manager.cpp  -  everything about WiFi
 *
 * - joins the best available network from: networks saved on the web page + built-in DEFAULT_WIFI_LIST
 * - if nothing can be joined for AP_START_DELAY_MS -> starts the setup hotspot (AP_SSID)
 * - starts mDNS (http://mydevice.local) and NTP time once connected
 * - runs in its own FreeRTOS task, so UART reading is never blocked
 */
#pragma once
#include <Arduino.h>

void   wifiManagerBegin();
bool   wifiIsConnected();
bool   wifiApActive();
String wifiScanJson();      // async scan helper for the web page (see /api/wifi/scan)
