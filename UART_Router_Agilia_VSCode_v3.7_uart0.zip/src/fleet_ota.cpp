#include "fleet_ota.h"
#include "config.h"
#include "settings.h"
#include "net_manager.h"
#include "device_id.h"
#include "fleet_logic.h"
#include "ota_update.h"
#include "utils.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Update.h>
#include <mbedtls/sha256.h>

static SemaphoreHandle_t mux;
static volatile bool wantCheck = false, wantInstall = false;

// state shown on the web page (protected by mux)
static uint32_t lastCheckMs = 0;
static bool     everChecked = false;
static String   statusText = "not checked yet";
static bool     available = false, offerForce = false;
static String   offVersion, offUrl, offSha, offRule;
static uint32_t offSize = 0;
static String   checkedModel, checkedSerial;       // identity the offer was made for
static bool     installing = false;
static int      progress = 0;
static uint32_t nextCheckMs = 0;

static void setStatus(const String& s) {
  xSemaphoreTake(mux, portMAX_DELAY);
  statusText = s;
  xSemaphoreGive(mux);
  Serial.printf("Fleet OTA: %s\n", s.c_str());
}

// ---------------------------------------------------------------- HTTP helpers
// Base URL = the update server. Empty setting = same scheme/host/port as the data server (and its header is sent too).
static bool buildBase(String& base, bool& sendHeader) {
  FleetCfg f;
  settingsGetFleet(f);
  if (f.baseUrl.length()) { base = f.baseUrl; sendHeader = false; return true; }
  ServerCfg s;
  settingsGetServer(s);
  if (!s.enabled()) return false;
  const uint16_t defPort = (s.scheme == "https") ? 443 : 80;
  base = s.scheme + "://" + s.host;
  if (s.port != 0 && s.port != defPort) base += ":" + String((unsigned)s.port);
  sendHeader = true;
  return true;
}

static bool beginHttp(HTTPClient& http, WiFiClient& plain, WiFiClientSecure& sec, const String& url, bool sendHeader) {
  bool ok;
  if (url.startsWith("https://")) {
    const char* ca = HTTPS_ROOT_CA;
    if (ca) sec.setCACert(ca); else sec.setInsecure();
    ok = http.begin(sec, url);
  } else {
    ok = http.begin(plain, url);
  }
  if (!ok) return false;
  http.setConnectTimeout(HTTP_TIMEOUT_MS);
  http.setTimeout(HTTP_TIMEOUT_MS);
  http.setReuse(false);
  if (sendHeader) {
    ServerCfg s;
    settingsGetServer(s);
    if (s.hdrName.length() && s.hdrValue.length()) http.addHeader(s.hdrName, s.hdrValue);
  }
  return true;
}

static String enc(const String& s) { return String(fleetUrlEncode(s.c_str()).c_str()); }

// ---------------------------------------------------------------- 1. ask the server
static void checkOnce() {
  DeviceIdentity id;
  deviceIdGet(id);
#if FLEET_REQUIRE_LIVE_DEVICE
  if (!id.known || !id.live) { setStatus("waiting: the connected device is not known yet (no frame from it in the last " + String(FLEET_LIVE_WINDOW_MS / 60000) + " min)"); return; }
#else
  if (!id.known) { setStatus("waiting: the connected device is not known yet"); return; }
#endif
  String base; bool hdr = false;
  if (!buildBase(base, hdr)) { setStatus("no update server: set a server on the Settings page or an update server URL below"); return; }
  FleetCfg f;
  settingsGetFleet(f);

  String url = String(fleetResolveUrl(base.c_str(), f.path.c_str()).c_str());
  url += "?gw=" + enc(HOSTNAME) + "&mac=" + enc(netMacString()) + "&fw=" + enc(FW_VERSION) + "&iface=" + enc(netActiveIface());
  url += "&class=" + enc(id.cls) + "&model=" + enc(id.model) + "&serial=" + enc(id.serial) + "&devver=" + enc(id.version);
  url += "&manual=" + String(id.manual ? 1 : 0) + "&last=" + enc(settingsNoteGet("fo_res"));

  HTTPClient http;
  WiFiClient plain;
  WiFiClientSecure sec;
  if (!beginHttp(http, plain, sec, url, hdr)) { setStatus("check failed: bad update server URL"); return; }
  int code = http.GET();
  String body;
  if (code == 200) {
    int sz = http.getSize();
    if (sz > 4096) code = -200; else body = http.getString();
  }
  http.end();

  xSemaphoreTake(mux, portMAX_DELAY);
  lastCheckMs = millis();
  everChecked = true;
  xSemaphoreGive(mux);

  if (code != 200) { setStatus(code == -200 ? String("check failed: answer too large") : "check failed, HTTP code " + String(code)); return; }

  const std::string b = body.c_str();
  bool upd = false;
  if (!fleetJsonBool(b, "update", upd)) { setStatus("check failed: the server answer has no \"update\" field"); return; }
  if (!upd) {
    std::string why;
    fleetJsonString(b, "reason", why);
    xSemaphoreTake(mux, portMAX_DELAY); available = false; xSemaphoreGive(mux);
    setStatus(String("up to date") + (why.empty() ? "" : String(" (") + why.c_str() + ")"));
    return;
  }

  std::string ver, uri, sha, rule;
  uint32_t size = 0;
  bool force = false;
  fleetJsonString(b, "version", ver);
  fleetJsonString(b, "url", uri);
  fleetJsonString(b, "sha256", sha);
  fleetJsonString(b, "rule", rule);
  fleetJsonUInt(b, "size", size);
  fleetJsonBool(b, "force", force);

  if (ver.empty() || uri.empty())  { setStatus("check failed: the update offer has no version or url"); return; }
  if (!fleetIsSha256Hex(sha))      { setStatus("refused: the update offer has no valid sha256"); return; }
  if (size == 0 || size > FLEET_MAX_IMAGE_BYTES) { setStatus("refused: the update offer has a missing or too large size (" + String(size) + " bytes)"); return; }
  if (ver == FW_VERSION)           { xSemaphoreTake(mux, portMAX_DELAY); available = false; xSemaphoreGive(mux); setStatus("up to date (server offers the version already running)"); return; }
  if (fleetVersionCompare(ver, FW_VERSION) <= 0 && !force) {
    xSemaphoreTake(mux, portMAX_DELAY); available = false; xSemaphoreGive(mux);
    setStatus("server offers " + String(ver.c_str()) + ", which is not newer than the running " FW_VERSION " - ignored");
    return;
  }

  xSemaphoreTake(mux, portMAX_DELAY);
  available = true;
  offerForce = force;
  offVersion = ver.c_str();
  offUrl = String(fleetResolveUrl(base.c_str(), uri).c_str());
  offSha = sha.c_str();
  offRule = rule.c_str();
  offSize = size;
  checkedModel = id.model;
  checkedSerial = id.serial;
  xSemaphoreGive(mux);
  setStatus("update available: " + String(ver.c_str()) + (rule.empty() ? "" : String("  (rule: ") + rule.c_str() + ")"));
}

// ---------------------------------------------------------------- 2. download, verify, switch
static bool downloadAndInstall(const String& url, bool sendHeader, uint32_t expectLen, const String& wantSha, const String& version, String& err) {
  if (!otaBusyTry()) { err = "another firmware update is running"; return false; }

  HTTPClient http;
  WiFiClient plain;
  WiFiClientSecure sec;
  bool ok = false;
  mbedtls_sha256_context sha;
  bool shaOpen = false;
  bool updateOpen = false;

  do {
    if (!beginHttp(http, plain, sec, url, sendHeader)) { err = "bad firmware URL"; break; }
    int code = http.GET();
    if (code != 200) { err = "download failed, HTTP code " + String(code); break; }
    int len = http.getSize();
    if (len <= 0)                          { err = "the server did not send a file size (Content-Length)"; break; }
    if ((uint32_t)len > FLEET_MAX_IMAGE_BYTES) { err = "firmware file is too large"; break; }
    if (expectLen && (uint32_t)len != expectLen) { err = "file size " + String(len) + " differs from the offered size " + String(expectLen); break; }
    if (!Update.begin(len)) { err = String("not enough room for the update: ") + Update.errorString(); break; }
    updateOpen = true;

    mbedtls_sha256_init(&sha);
    mbedtls_sha256_starts_ret(&sha, 0);
    shaOpen = true;

    WiFiClient* stream = http.getStreamPtr();
    static uint8_t buf[1024];
    int written = 0;
    uint32_t lastData = millis();
    bool failed = false;
    while (written < len) {
      size_t avail = stream->available();
      if (avail) {
        int n = stream->readBytes(buf, avail > sizeof(buf) ? sizeof(buf) : avail);
        if (n <= 0) { failed = true; err = "read error"; break; }
        if ((int)Update.write(buf, n) != n) { failed = true; err = String("flash write failed: ") + Update.errorString(); break; }
        mbedtls_sha256_update_ret(&sha, buf, n);
        written += n;
        lastData = millis();
        xSemaphoreTake(mux, portMAX_DELAY); progress = (int)((int64_t)written * 100 / len); xSemaphoreGive(mux);
      } else {
        if (!http.connected()) { failed = true; err = "connection closed after " + String(written) + " of " + String(len) + " bytes"; break; }
        if (millis() - lastData > 20000) { failed = true; err = "download timed out"; break; }
        vTaskDelay(pdMS_TO_TICKS(5));
      }
    }
    if (failed) break;

    unsigned char digest[32];
    mbedtls_sha256_finish_ret(&sha, digest);
    char hex[65];
    for (int i = 0; i < 32; i++) snprintf(hex + i * 2, 3, "%02x", digest[i]);
    if (!fleetHexEqual(hex, wantSha.c_str())) { err = String("SHA-256 mismatch (file ") + hex + ", offered " + wantSha + ") - image NOT installed"; break; }

    if (!Update.end(true)) { err = String("update could not be finished: ") + Update.errorString(); updateOpen = false; break; }
    updateOpen = false;
    ok = true;
  } while (false);

  http.end();
  if (shaOpen) mbedtls_sha256_free(&sha);
  if (!ok && updateOpen) Update.abort();           // nothing was activated
  otaBusyClear();
  return ok;
}

static void installOffer(bool manual) {
  String url, sha, ver, mdl, ser;
  uint32_t size;
  xSemaphoreTake(mux, portMAX_DELAY);
  url = offUrl; sha = offSha; ver = offVersion; size = offSize; mdl = checkedModel; ser = checkedSerial;
  xSemaphoreGive(mux);

  // the device must still be the one the rule was made for
  DeviceIdentity id;
  deviceIdGet(id);
#if FLEET_REQUIRE_LIVE_DEVICE
  if (!id.known || !id.live) { setStatus("install postponed: the connected device is no longer known"); return; }
#endif
  if (id.model != mdl || id.serial != ser) { setStatus("install postponed: a different device is connected now - checking again"); wantCheck = true; return; }
  if (!manual && FLEET_AVOID_INFUSING && id.infusing) { setStatus("install postponed: the device reports an infusion in progress (will retry)"); return; }
  if (!manual && settingsNoteGet("fo_bad") == ver) {
    setStatus("not installed again: version " + ver + " was installed before but the new image still reported another version (is FW_VERSION in config.h of that build correct?). Use Install now to force it.");
    xSemaphoreTake(mux, portMAX_DELAY); available = false; xSemaphoreGive(mux);
    return;
  }

  bool sendHdr = false;
  { String base; buildBase(base, sendHdr); if (!url.startsWith(base)) sendHdr = false; }   // never send the data-server key to another host

  xSemaphoreTake(mux, portMAX_DELAY); installing = true; progress = 0; xSemaphoreGive(mux);
  setStatus("installing " + ver + " ...");
  String err;
  bool ok = downloadAndInstall(url, sendHdr, size, sha, ver, err);
  xSemaphoreTake(mux, portMAX_DELAY); installing = false; xSemaphoreGive(mux);

  if (ok) {
    settingsNoteSet("fo_pend", ver);                  // checked at the next boot (fleetBegin)
    setStatus("installed " + ver + " - rebooting");
    delay(800);
    ESP.restart();
  } else {
    settingsNoteSet("fo_res", "fail: " + err);
    xSemaphoreTake(mux, portMAX_DELAY); available = false; xSemaphoreGive(mux);      // retried at the next scheduled check
    setStatus("install failed: " + err);
  }
}

// ---------------------------------------------------------------- task
static void fleetTask(void*) {
  const uint32_t bootMs = millis();
  uint32_t lastCheck = 0, lastAutoTry = 0;
  bool first = true;
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(1000));
    FleetCfg f;
    settingsGetFleet(f);
    if (f.mode == 0) { wantCheck = false; wantInstall = false; continue; }
    if (!netIsUp()) continue;

    const uint32_t now = millis();
    const bool due = first ? (now - bootMs >= FLEET_FIRST_CHECK_MS) : (now - lastCheck >= (uint32_t)f.intervalMin * 60000UL);
    xSemaphoreTake(mux, portMAX_DELAY);
    nextCheckMs = first ? (bootMs + FLEET_FIRST_CHECK_MS) : (lastCheck + (uint32_t)f.intervalMin * 60000UL);
    xSemaphoreGive(mux);
    if (wantCheck || due) {
      wantCheck = false;
      first = false;
      lastCheck = millis();
      checkOnce();
    }

    bool avail;
    xSemaphoreTake(mux, portMAX_DELAY); avail = available; xSemaphoreGive(mux);
    if (wantInstall) {
      wantInstall = false;
      if (avail) installOffer(true); else setStatus("nothing to install: check first");
    } else if (f.mode == 2 && avail && (lastAutoTry == 0 || millis() - lastAutoTry >= 30000)) {
      lastAutoTry = millis() ? millis() : 1;
      installOffer(false);
    }
  }
}

void fleetBegin() {
  mux = xSemaphoreCreateMutex();
  // First boot after a server-managed install: did the new image really come up with the offered version?
  String pend = settingsNoteGet("fo_pend");
  if (pend.length()) {
    settingsNoteSet("fo_pend", "");
    if (pend == FW_VERSION) { settingsNoteSet("fo_res", "ok " + pend); settingsNoteSet("fo_bad", ""); Serial.printf("Fleet OTA: update to %s confirmed\n", pend.c_str()); }
    else { settingsNoteSet("fo_res", "fail: new image reports " FW_VERSION " instead of " + pend); settingsNoteSet("fo_bad", pend); Serial.printf("Fleet OTA: WARNING offered %s but running %s\n", pend.c_str(), FW_VERSION); }
  }
  xTaskCreatePinnedToCore(fleetTask, "fleetOta", 12288, nullptr, 1, nullptr, 0);
}

void fleetCheckNow() { wantCheck = true; }

bool fleetInstallNow() {
  bool avail;
  xSemaphoreTake(mux, portMAX_DELAY); avail = available; xSemaphoreGive(mux);
  if (!avail) return false;
  wantInstall = true;
  return true;
}

String fleetStatusJson() {
  FleetCfg f;
  settingsGetFleet(f);
  xSemaphoreTake(mux, portMAX_DELAY);
  String j = "{\"mode\":" + String(f.mode);
  j += ",\"checked\":" + String(everChecked ? "true" : "false");
  j += ",\"ago_s\":" + String(everChecked ? (millis() - lastCheckMs) / 1000 : 0);
  { int32_t d = (int32_t)(nextCheckMs - millis()); j += ",\"next_s\":" + String(d > 0 ? d / 1000 : 0); }
  j += ",\"status\":\"" + jsonEscape(statusText) + "\"";
  j += ",\"available\":" + String(available ? "true" : "false");
  j += ",\"version\":\"" + jsonEscape(offVersion) + "\",\"rule\":\"" + jsonEscape(offRule) + "\"";
  j += ",\"force\":" + String(offerForce ? "true" : "false") + ",\"size\":" + String(offSize);
  j += ",\"installing\":" + String(installing ? "true" : "false") + ",\"progress\":" + String(progress);
  j += ",\"running\":\"" FW_VERSION "\"";
  j += ",\"last_result\":\"" + jsonEscape(settingsNoteGet("fo_res")) + "\"";
  j += ",\"avoid_infusing\":" + String(FLEET_AVOID_INFUSING ? "true" : "false");
  j += "}";
  xSemaphoreGive(mux);
  return j;
}
