#include "ota_update.h"
#include "web_server.h"
#include "pump_reader.h"
#include "device_id.h"
#include "fleet_logic.h"
#include "config.h"
#include <Update.h>
#include <mbedtls/sha256.h>

static volatile bool          busy = false;
static bool                   haveLock = false;       // this web upload holds the lock
static bool                   uploadOk = false;       // upload started and no error so far
static int                    rejectCode = 0;         // != 0 -> answer with this HTTP code
static String                 rejectText;
static mbedtls_sha256_context sha;
static bool                   shaOpen = false;
static char                   shaHex[65] = "";
static uint32_t               totalBytes = 0;

bool otaBusyTry() {
  bool got = false;
  noInterrupts();
  if (!busy) { busy = true; got = true; }
  interrupts();
  return got;
}
void otaBusyClear() { busy = false; }
bool otaBusy()      { return busy; }

static void shaClose(bool finish) {
  if (!shaOpen) return;
  if (finish) {
    unsigned char out[32];
    mbedtls_sha256_finish_ret(&sha, out);
    for (int i = 0; i < 32; i++) snprintf(shaHex + i * 2, 3, "%02x", out[i]);
  }
  mbedtls_sha256_free(&sha);
  shaOpen = false;
}

static void reject(int code, const String& why) {
  rejectCode = code;
  rejectText = why;
  Serial.printf("OTA refused: %s\n", why.c_str());
}

void otaHandleDone() {
  if (!webCheckAuth()) return;
  server.sendHeader("Connection", "close");
  if (rejectCode) {
    server.send(rejectCode, "text/plain", "Update REFUSED: " + rejectText);
    rejectCode = 0;
    if (haveLock) { otaBusyClear(); haveLock = false; }
    return;
  }
  bool ok = uploadOk && !Update.hasError();
  if (ok) server.send(200, "text/plain", String("Update OK, sha256 ") + shaHex + ", rebooting");
  else    server.send(500, "text/plain", String("Update FAILED: ") + Update.errorString());
  delay(500);
  if (haveLock) { otaBusyClear(); haveLock = false; }
  if (ok) ESP.restart();
}

void otaHandleUpload() {
  if (!server.authenticate(WEB_USER, WEB_PASS)) return;
  HTTPUpload& up = server.upload();

  if (up.status == UPLOAD_FILE_START) {
    rejectCode = 0; uploadOk = false; totalBytes = 0; shaHex[0] = 0;
    Serial.printf("OTA start: %s\n", up.filename.c_str());

    if (!otaBusyTry()) { haveLock = false; reject(409, "another firmware update is already running"); return; }
    haveLock = true;

    // ---- target guard: only accept the image if the connected device matches
    FleetTarget t;
    t.cls    = server.arg("tcls").c_str();
    t.model  = server.arg("tmodel").c_str();
    t.serial = server.arg("tserial").c_str();
    if (!t.any()) {
      DeviceIdentity id;
      deviceIdGet(id);
      std::string why;
      if (!id.known || !id.live) {
        reject(409, "a target (class / model / serial) was given, but this gateway does not know what is connected "
                    "(no frame from the device in the last " + String(FLEET_LIVE_WINDOW_MS / 60000) + " minutes). Power on the device or type it in on the Settings page.");
        return;
      }
      if (!fleetTargetMatches(t, id.cls.c_str(), id.model.c_str(), id.serial.c_str(), why)) {
        reject(409, String("this gateway is connected to ") + id.model + " serial " + id.serial + ": " + why.c_str());
        return;
      }
    }

    if (!Update.begin(UPDATE_SIZE_UNKNOWN)) { Update.printError(Serial); return; }
    mbedtls_sha256_init(&sha);
    mbedtls_sha256_starts_ret(&sha, 0);
    shaOpen = true;
    uploadOk = true;

  } else if (up.status == UPLOAD_FILE_WRITE) {
    if (!uploadOk || rejectCode) return;
    mbedtls_sha256_update_ret(&sha, up.buf, up.currentSize);
    totalBytes += up.currentSize;
    if (Update.write(up.buf, up.currentSize) != up.currentSize) { Update.printError(Serial); uploadOk = false; }
    pumpPoll();                      // keep draining the pump UART while uploading

  } else if (up.status == UPLOAD_FILE_END) {
    if (!uploadOk || rejectCode) { shaClose(false); return; }
    shaClose(true);
    if (Update.end(true)) Serial.printf("OTA success: %u bytes, sha256 %s\n", (unsigned)up.totalSize, shaHex);
    else { Update.printError(Serial); uploadOk = false; }

  } else if (up.status == UPLOAD_FILE_ABORTED) {
    shaClose(false);
    if (uploadOk) Update.abort();
    uploadOk = false;
    if (haveLock) { otaBusyClear(); haveLock = false; }
    Serial.println("OTA aborted");
  }
}
